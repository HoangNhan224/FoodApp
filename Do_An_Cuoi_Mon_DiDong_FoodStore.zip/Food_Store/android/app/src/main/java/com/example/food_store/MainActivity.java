package com.example.food_store;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
